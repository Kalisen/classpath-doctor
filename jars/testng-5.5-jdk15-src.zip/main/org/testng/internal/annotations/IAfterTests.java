package org.testng.internal.annotations;

public interface IAfterTests extends IBaseBeforeAfter {

}
